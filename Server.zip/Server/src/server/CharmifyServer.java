/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;
import java.io.*; 
import java.net.*; 
import java.util.concurrent.CopyOnWriteArrayList;
public class CharmifyServer {
private static final int PORT = 5000;

private static final Inventory inventory = new Inventory();

private static final CopyOnWriteArrayList<ClientHandler> clients =
        new CopyOnWriteArrayList<>();

private static volatile boolean running = false;
private static ServerSocket serverSocket;
private static ServerGUI gui;

public static Inventory getInventory() {
    return inventory;
}

public static void startServer(ServerGUI serverGUI) {

    if (running) {
        return;
    }

    gui = serverGUI;

    try {
        serverSocket = new ServerSocket(PORT);
        running = true;

        gui.setServerStatus(true);
        gui.log("Server started on port " + PORT);

        while (running) {

            Socket socket = serverSocket.accept();

            ClientHandler client = new ClientHandler(socket);
            clients.add(client);
            client.start();

            gui.updateClientCount(clients.size());
        }

    } catch (IOException e) {

        if (running) {
            gui.log("Server error: " + e.getMessage());
        }

    } finally {

        running = false;

        for (ClientHandler client : clients) {
            client.closeConnection();
        }

        if (serverSocket != null) {
            try {
                serverSocket.close();
            } catch (IOException e) {
                // Socket already closed
            }
        }

        gui.setServerStatus(false);
        gui.updateClientCount(clients.size());
    }
}

public static void stopServer() {

    running = false;

    if (gui != null) {
        gui.log("Stopping server...");
    }

    if (serverSocket != null) {
        try {
            serverSocket.close();
        } catch (IOException e) {
            // Server already stopped
        }
    }
}

public static void broadcast(String message) {

    for (ClientHandler client : clients) {
        client.sendMessage(message);
    }
}

public static void removeClient(ClientHandler client) {

    clients.remove(client);

    if (gui != null) {
        gui.updateClientCount(clients.size());
    }
}

public static void log(String message) {

    System.out.println(message);

    if (gui != null) {
        gui.log(message);
    }
}
}