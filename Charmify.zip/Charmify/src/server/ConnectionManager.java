package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class ConnectionManager {

    private final Socket socket;
    private final BufferedReader reader;
    private final PrintWriter writer;
    private final String username;
    private final JFrame ownerFrame;
    private StoreGUI storeGUI;
    private CartFrame cartFrame;

    public ConnectionManager(Socket socket, String username, JFrame ownerFrame) throws IOException {
        this.socket = socket;
        this.username = username;
        this.ownerFrame = ownerFrame;
        this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.writer = new PrintWriter(socket.getOutputStream(), true);
    }

    public void attachFrames(StoreGUI storeGUI, CartFrame cartFrame) {
        this.storeGUI = storeGUI;
        this.cartFrame = cartFrame;
        if (this.cartFrame != null) {
            this.cartFrame.setOrderHandler(this::sendOrderRequest);
        }
    }

    // FIX 2: get the real cart window from StoreGUI (it is created later)
    private CartFrame getCart() {
        if (cartFrame != null) {
            return cartFrame;
        }
        return (storeGUI != null) ? storeGUI.getCartFrame() : null;
    }

    // FIX 7: show messages on a window that is still open
    private JFrame messageParent() {
        CartFrame cart = getCart();
        if (cart != null && cart.isDisplayable() && cart.isVisible()) {
            return cart;
        }
        return (storeGUI != null) ? storeGUI : ownerFrame;
    }

    // ===================== SEND TO SERVER =====================

    public void sendCartRequest(int productId, int quantity) {
        writer.println("CART:" + productId + ":" + quantity);
    }

    public void sendOrderRequest(List<Cart.CartItem> items) {
        if (items == null || items.isEmpty()) {
            return;
        }
        StringBuilder sb = new StringBuilder("ORDER:" + username);
        for (Cart.CartItem item : items) {
            int productId = (item.getCategory() + 1) * 100 + item.getIndex() + 1;
            sb.append(";").append(productId).append(",").append(item.getQuantity());
        }
        writer.println(sb.toString());
    }

    // FIX 4: order ID is a long (same as MyOrdersFrame)
    public void sendCancelOrderRequest(long orderId) {
        writer.println("CANCEL_ORDER:" + username + ":" + orderId);
    }

    // FIX 4: ask the server for this user's orders
    public void sendOrdersRequest() {
        writer.println("GET_ORDERS");
    }

    // ===================== RECEIVE FROM SERVER =====================

    public void handleServerMessage(String serverMessage) {
        if (serverMessage == null) {
            return;
        }

        try {
            String[] parts = serverMessage.split(":");

            if (serverMessage.startsWith("stock:")) {
                int productId = Integer.parseInt(parts[1]);
                int newStock = Integer.parseInt(parts[2]);
                if (storeGUI != null) {
                    storeGUI.updateProductStock(productId / 100 - 1, productId % 100 - 1, newStock);
                }

            } else if (serverMessage.startsWith("UPDATED_CART:")) {
                int productId = Integer.parseInt(parts[1]);
                int quantity = Integer.parseInt(parts[2]);
                if (storeGUI != null) {
                    storeGUI.applyServerCartUpdate(productId / 100 - 1, productId % 100 - 1, quantity);
                }

            } else if (serverMessage.startsWith("ORDER_CONFIRMED:")) {
                // ORDER_CONFIRMED:<id>:101-2,202-1
                long orderId = Long.parseLong(parts[1]);
                String items = parts.length > 2 ? parts[2] : "";

                if (storeGUI != null) {
                    storeGUI.onOrderConfirmed(orderId, items);       // FIX 3
                }
                CartFrame cart = getCart();
                if (cart != null) {
                    cart.clearAfterSuccessfulOrder();                // FIX 2 (also shows the message)
                } else {
                    showMessage("Order Confirmed", "Your order has been confirmed!");
                }

            } else if (serverMessage.startsWith("ORDER_REJECTED")) {
                String reason = serverMessage.contains(":")
                        ? serverMessage.substring(serverMessage.indexOf(":") + 1).trim()
                        : "Your order could not be completed.";
                CartFrame cart = getCart();
                if (cart != null) {
                    cart.handleOrderRejected(reason);                // FIX 2
                } else {
                    showMessage("Order Rejected", reason);
                }

            } else if (serverMessage.startsWith("ORDER_CANCELLED:")) {
                long orderId = Long.parseLong(parts[1]);
                if (storeGUI != null) {
                    storeGUI.onOrderCancelled(orderId);              // FIX 3
                }
                showMessage("Order Cancelled", "Your order has been cancelled successfully.");

            } else if (serverMessage.startsWith("CANCEL_REJECTED")) {
                if (parts.length > 1 && storeGUI != null) {
                    storeGUI.onCancelRejected(Long.parseLong(parts[1]));
                }
                showMessage("Cancellation Failed", "Sorry, this order could not be cancelled.");

            } else if (serverMessage.equals("ORDERS_BEGIN")) {
                if (storeGUI != null) {
                    storeGUI.clearOrders();                          // FIX 3
                }

            } else if (serverMessage.startsWith("ORDER_ENTRY:")) {
                // ORDER_ENTRY:<id>:101-2,202-1:PLACED
                long orderId = Long.parseLong(parts[1]);
                String items = parts[2];
                boolean cancelled = parts.length > 3 && parts[3].equals("CANCELLED");
                if (storeGUI != null) {
                    storeGUI.loadOrderFromServer(orderId, items, cancelled);
                }
            }
            // "stockEnd" and "ORDERS_END" need no action

        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            System.out.println("Invalid message from server: " + serverMessage);
        }
    }

    private void showMessage(String title, String text) {
        SwingUtilities.invokeLater(() ->
                CartFrame.showPinkMessage(messageParent(), title, text));
    }

    public void startListeningThread() {
        Thread listenerThread = new Thread(() -> {
            try {
                String serverMessage;
                while ((serverMessage = reader.readLine()) != null) {
                    handleServerMessage(serverMessage);
                }
            } catch (IOException e) {
                System.out.println("Connection closed or lost.");
            }
        });
        listenerThread.setDaemon(true);
        listenerThread.start();
    }

    public Socket getSocket() { return socket; }
    public BufferedReader getReader() { return reader; }
    public PrintWriter getWriter() { return writer; }
}