package server;

import java.util.ArrayList;

public class Inventory {

    private ArrayList<Product> products;

    public Inventory() {
        products = new ArrayList<>();

        // Phone Cases
        products.add(new Product(101, "Pearl Case", Category.PHONE_CASE, 45.0, 10, "/images/pearl_case.png"));
        products.add(new Product(102, "Pink Glitter Case", Category.PHONE_CASE, 45.0, 10, "/images/pink_glitter_case.png"));
        products.add(new Product(103, "Hearts Case", Category.PHONE_CASE, 45.0, 10, "/images/hearts_case.png"));
        products.add(new Product(104, "Blue Wave Case", Category.PHONE_CASE, 45.0, 10, "/images/blue_wave_case.png"));

        // Charms
        products.add(new Product(201, "White Bow Charm", Category.CHARM, 8.0, 15, "/images/white_bow_charm.png"));
        products.add(new Product(202, " Pink Hearts Charm", Category.CHARM, 8.0, 15, "/images/pink_hearts_charm.png"));
        products.add(new Product(203, "Pink Stars Charm", Category.CHARM, 8.0, 15, "/images/pink_stars_charm.png"));
        products.add(new Product(204, "Seashell Fan Charm", Category.CHARM, 8.0, 15, "/images/seashell_fan_charm.png"));

        // Stickers
        products.add(new Product(301, "Butterfly Sticker", Category.STICKER, 10.0, 20, "/images/butterfly_sticker.png"));
        products.add(new Product(302, "Star Sticker", Category.STICKER, 10.0, 20, "/images/star_sticker.png"));
        products.add(new Product(303, "Blue Shell Sticker", Category.STICKER, 10.0, 20, "/images/blue_shell_sticker.png"));
        products.add(new Product(304, "Gold Heart Sticker", Category.STICKER, 10.0, 20, "/images/gold_heart_sticker.png"));
    }

    // Search for a product by its id
    public synchronized Product getProductById(int id) {
        for (Product product : products) {
            if (product.getID() == id) {
                return product;
            }
        }
        return null;
    }

    public synchronized int getStock(int id) {
        Product p = getProductById(id);
        if (p != null) {
            return p.getStock();
        }
        return -1;
    }

    // PHASE 2: reduce stock after a confirmed order
    public synchronized boolean reduceStock(int id, int quantity) {
        Product p = getProductById(id);
        if (p == null || quantity <= 0 || p.getStock() < quantity) {
            return false;
        }
        p.setStock(p.getStock() - quantity);
        return true;
    }

    // PHASE 2: give the stock back when an order is cancelled
    public synchronized void restoreStock(int id, int quantity) {
        Product p = getProductById(id);
        if (p != null && quantity > 0) {
            p.setStock(p.getStock() + quantity);
        }
    }

    public synchronized ArrayList<Product> getAllProducts() {
        return new ArrayList<>(products);
    }
}