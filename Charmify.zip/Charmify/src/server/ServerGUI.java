/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;
import javax.swing.*; 
import java.awt.*;
public class ServerGUI extends JFrame {
private JLabel statusLabel;
private JLabel clientsLabel;
private JTextArea activityArea;
private JButton startButton;
private JButton stopButton;

public ServerGUI() {

    setTitle("Charmify Server");
    setSize(550, 500);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);

    Color pink = new Color(210, 70, 115);
    Color lightPink = new Color(255, 235, 242);

JPanel panel = new JPanel() {
@Override
protected void paintComponent(Graphics g) {
    super.paintComponent(g);

    Graphics2D g2 = (Graphics2D) g.create();

    g2.setRenderingHint(
        RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON
    );

    int w = getWidth();
    int h = getHeight();

    // Soft pink gradient
    GradientPaint gradient = new GradientPaint(
        0, 0, new Color(255, 235, 245),
        w, h, new Color(255, 250, 253)
    );

    g2.setPaint(gradient);
    g2.fillRect(0, 0, w, h);

    // Top-left pink wave
    g2.setColor(new Color(250, 192, 212, 115));

    g2.fillOval(-170, -145, 350, 260);
    g2.fillOval(-110, -90, 260, 180);

    // Bottom-right pink wave
    g2.setColor(new Color(248, 185, 210, 100));

    g2.fillOval(w - 145, h - 115, 280, 210);
    g2.fillOval(w - 85, h - 65, 200, 145);

    // Thin decorative curved lines
    g2.setColor(new Color(220, 100, 150, 95));
    g2.setStroke(new BasicStroke(1.8f));

    g2.drawArc(-85, 110, 200, 160, 180, 145);
    g2.drawArc(w - 115, 75, 190, 230, 35, 150);

    // Hearts
    g2.setColor(new Color(210, 90, 135, 110));
    g2.setFont(new Font("SansSerif", Font.PLAIN, 25));

    g2.drawString("♥", 30, 170);
    g2.drawString("♥", w - 65, h - 75);

    // Sparkles
    g2.setFont(new Font("SansSerif", Font.PLAIN, 22));

    g2.drawString("✦", w - 55, 160);
    g2.drawString("✦", 45, h - 65);

    g2.dispose();
}
};
panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

panel.setBorder(
    BorderFactory.createEmptyBorder(20, 25, 20, 25)
);

  ImageIcon icon = new ImageIcon(
    getClass().getResource("/images/logo2.png")
);

int width = 260;
int height = (int) (
    icon.getIconHeight() *
    ((double) width / icon.getIconWidth())
);

java.awt.image.BufferedImage resized =
    new java.awt.image.BufferedImage(
        width, height,
        java.awt.image.BufferedImage.TYPE_INT_ARGB
    );

Graphics2D g2 = resized.createGraphics();

g2.setRenderingHint(
    RenderingHints.KEY_INTERPOLATION,
    RenderingHints.VALUE_INTERPOLATION_BICUBIC
);

g2.drawImage(icon.getImage(), 0, 0, width, height, null);
g2.dispose();

JLabel title = new JLabel(new ImageIcon(resized));
title.setAlignmentX(Component.CENTER_ALIGNMENT);

    statusLabel = new JLabel("Server Status: Stopped");
    statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

    clientsLabel = new JLabel("Connected Clients: 0");
    clientsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

    activityArea = new JTextArea();
    activityArea.setEditable(false);
    activityArea.setFont(new Font("Arial", Font.PLAIN, 14));

    JScrollPane scrollPane = new JScrollPane(activityArea);

    startButton = new JButton("Start Server");
    stopButton = new JButton("Stop Server");

    startButton.setBackground(pink);
    startButton.setForeground(Color.WHITE);

    stopButton.setBackground(pink);
    stopButton.setForeground(Color.WHITE);
    stopButton.setEnabled(false);

    startButton.addActionListener(e -> {
        startButton.setEnabled(false);
        new Thread(() -> CharmifyServer.startServer(this)).start();
    });

    stopButton.addActionListener(e -> CharmifyServer.stopServer());

    JPanel buttons = new JPanel();
    buttons.setOpaque(false);
    buttons.add(startButton);
    buttons.add(stopButton);

    panel.add(title);
    panel.add(Box.createVerticalStrut(20));
    panel.add(statusLabel);
    panel.add(Box.createVerticalStrut(10));
    panel.add(clientsLabel);
    panel.add(Box.createVerticalStrut(20));
    panel.add(scrollPane);
    panel.add(Box.createVerticalStrut(15));
    panel.add(buttons);

    add(panel);
}

public void setServerStatus(boolean running) {
    SwingUtilities.invokeLater(() -> {
        statusLabel.setText("Server Status: "
                + (running ? "Running" : "Stopped"));
        startButton.setEnabled(!running);
        stopButton.setEnabled(running);
    });
}

public void updateClientCount(int count) {
    SwingUtilities.invokeLater(() ->
            clientsLabel.setText("Connected Clients: " + count));
}

public void log(String message) {
    SwingUtilities.invokeLater(() ->
            activityArea.append(message + "\n"));
}

public static void main(String[] args) {
    SwingUtilities.invokeLater(() ->
            new ServerGUI().setVisible(true));
}
}
