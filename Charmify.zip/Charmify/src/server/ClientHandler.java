/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

/**
 *
 * @author Dell
 */
import java.io.*; 
import java.net.*;
public class ClientHandler implements Runnable {
private Socket socket;
private BufferedReader in;
private PrintWriter out;
private String username;

public ClientHandler(Socket socket) {
    this.socket = socket;
}

@Override
public void run() {

    try {
        // Input stream
        in = new BufferedReader(
            new InputStreamReader(socket.getInputStream())
        );

        // Output stream
        out = new PrintWriter(
            socket.getOutputStream(), true
        );

        // Receive username
        username = in.readLine();

        if (username == null || username.trim().isEmpty()) {
            return;
        }

        System.out.println(username + " joined Charmify!");

        // Confirm connection
        out.println("CONNECTED");

        // Receive messages from client
        String message;

        while ((message = in.readLine()) != null) {

            System.out.println(username + ": " + message);

            
           if (message.equalsIgnoreCase("get stock")) {
      Inventory inventory = CharmifyServer.getInventory();

   for (Product product : inventory.getAllProducts()) {
    out.println("stock:"
            + product.getID() + ":"
            + inventory.getStock(product.getID()));
   }

    out.println("stockEnd");
      }

        }//End while

    } catch (IOException e) {

        System.out.println("Connection error: " + e.getMessage());

    } finally {

        // Remove disconnected client
        CharmifyServer.removeClient(this);

        System.out.println("Client disconnected: " + username);

        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

// Send a message to this client
public void sendMessage(String message) {

    if (out != null) {
        out.println(message);
    }
}
// Close client connection
public void closeConnection() {
    try {
        socket.close();
    } catch (IOException e) {
        System.out.println("Error closing client connection");
    }
}

} // End ClientHandler
