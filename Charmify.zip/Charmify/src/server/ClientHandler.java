package server;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class ClientHandler implements Runnable {

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private String username;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            username = in.readLine();
            if (username == null || username.trim().isEmpty()) {
                return;
            }
            username = username.trim();

            CharmifyServer.log(username + " joined Charmify!");
            out.println("CONNECTED");

            String message;
            while ((message = in.readLine()) != null) {

                CharmifyServer.log(username + ": " + message);

                if (message.equalsIgnoreCase("get stock")) {
                    sendAllStock();
                } else if (message.startsWith("CART:")) {
                    handleCart(message);
                } else if (message.startsWith("ORDER:")) {          // PHASE 2
                    handleOrder(message);
                } else if (message.startsWith("CANCEL_ORDER:")) {   // PHASE 2
                    handleCancel(message);
                } else if (message.equals("GET_ORDERS")) {          // PHASE 2
                    sendUserOrders();
                }
            }

        } catch (IOException e) {
            CharmifyServer.log("Connection error: " + e.getMessage());
        } finally {
            CharmifyServer.removeClient(this);
            if (username != null && !username.isEmpty()) {
                CharmifyServer.log(username + " left Charmify.");
            }
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // ========== PHASE 1 ==========

    private void sendAllStock() {
        Inventory inventory = CharmifyServer.getInventory();
        for (Product product : inventory.getAllProducts()) {
            out.println("stock:" + product.getID() + ":" + inventory.getStock(product.getID()));
        }
        out.println("stockEnd");
    }

    private void handleCart(String message) {
        try {
            String[] parts = message.split(":");
            int productId = Integer.parseInt(parts[1]);
            int quantity = Integer.parseInt(parts[2]);

            Inventory inventory = CharmifyServer.getInventory();
            Product product = inventory.getProductById(productId);

            if (product != null && quantity >= 0) {
                int updatedQuantity = Math.min(quantity, inventory.getStock(productId));
                out.println("UPDATED_CART:" + productId + ":" + updatedQuantity);
                          CharmifyServer.log("Sent to " + username + ": UPDATED_CART:" + productId + ":" + updatedQuantity);
            }
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            CharmifyServer.log("Invalid cart request from " + username);
  
        }
    }

    // ========== PHASE 2 ==========

    // Receives: ORDER:user;101,2;202,1
    private void handleOrder(String message) {
        Inventory inventory = CharmifyServer.getInventory();
        List<Order.OrderItem> items = new ArrayList<>();

        try {
            String[] parts = message.split(";");
            for (int i = 1; i < parts.length; i++) {
                String[] pair = parts[i].split(",");
                int productId = Integer.parseInt(pair[0].trim());
                int quantity = Integer.parseInt(pair[1].trim());

                Product product = inventory.getProductById(productId);
                if (product == null || quantity <= 0) {
                    out.println("ORDER_REJECTED:Invalid product in your order.");
                    return;
                }
                items.add(new Order.OrderItem(productId, product.getName(),
                        product.getPrice(), quantity));
            }
            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            out.println("ORDER_REJECTED:Invalid order format.");
            return;
        }

        if (items.isEmpty()) {
            out.println("ORDER_REJECTED:Your cart is empty.");
            return;
        }

        Order order = new Order(username, items);

        // Check stock for all items, then reduce
        if (!order.applyToInventory(inventory)) {
            out.println("ORDER_REJECTED:Sorry, the quantity is more than what is in stock.");
            CharmifyServer.log("Order REJECTED for " + username);
            return;
        }

        CharmifyServer.getOrderStorage().addOrder(order);

        long orderId = order.getTimestampMillis();
        out.println("ORDER_CONFIRMED:" + orderId + ":" + itemsSpec(order));
        CharmifyServer.log("Order CONFIRMED for " + username + " (" + orderId + ")");

        // Update stock for ALL users
        for (Order.OrderItem item : items) {
            CharmifyServer.broadcastStock(item.getProductId());
        }
    }

    // Receives: CANCEL_ORDER:user:orderId
    private void handleCancel(String message) {
        String[] parts = message.split(":");
        long orderId;

        try {
            orderId = Long.parseLong(parts[parts.length - 1].trim());
        } catch (NumberFormatException e) {
            out.println("CANCEL_REJECTED");
            return;
        }

        Order order = findUserOrder(orderId);

        if (order == null || !order.cancel(CharmifyServer.getInventory())) {
            out.println("CANCEL_REJECTED:" + orderId);
            CharmifyServer.log("Cancel REJECTED for " + username);
            return;
        }

        CharmifyServer.getOrderStorage().recordCancell(order);

        out.println("ORDER_CANCELLED:" + orderId);
        CharmifyServer.log("Order CANCELLED for " + username + " (" + orderId + ")");

        // Update stock for ALL users
        for (Order.OrderItem item : order.getItems()) {
            CharmifyServer.broadcastStock(item.getProductId());
        }
    }

    // Receives: GET_ORDERS
    private void sendUserOrders() {
        out.println("ORDERS_BEGIN");
        for (Order order : CharmifyServer.getOrderStorage().getOrderByUser(username)) {
            out.println("ORDER_ENTRY:" + order.getTimestampMillis() + ":"
                    + itemsSpec(order) + ":" + order.getStatus());
        }
        out.println("ORDERS_END");
    }

    private Order findUserOrder(long orderId) {
        for (Order order : CharmifyServer.getOrderStorage().getOrderByUser(username)) {
            if (order.getTimestampMillis() == orderId) {
                return order;
            }
        }
        return null;
    }

    // Format used by MyOrdersFrame: "101-2,202-1"
    private String itemsSpec(Order order) {
        StringBuilder sb = new StringBuilder();
        for (Order.OrderItem item : order.getItems()) {
            if (sb.length() > 0) {
                sb.append(",");
            }
            sb.append(item.getProductId()).append("-").append(item.getQuantity());
        }
        return sb.toString();
    }

    // ========== helpers ==========

    public void sendMessage(String message) {
        if (out != null) {
            out.println(message);
        }
    }

    public void closeConnection() {
        try {
            socket.close();
        } catch (IOException e) {
            CharmifyServer.log("Error closing client connection");
        }
    }
}