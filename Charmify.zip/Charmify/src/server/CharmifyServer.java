package server;

import java.io.*;
import java.net.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class CharmifyServer {

    private static final int PORT = 5000;

    private static final Inventory inventory = new Inventory();
    private static final OrderStorage orderStorage = new OrderStorage(); // PHASE 2

    private static final CopyOnWriteArrayList<ClientHandler> clients =
            new CopyOnWriteArrayList<>();

    private static volatile boolean running = false;
    private static ServerSocket serverSocket;
    private static ServerGUI gui;

    public static Inventory getInventory() {
        return inventory;
    }

    // PHASE 2
    public static OrderStorage getOrderStorage() {
        return orderStorage;
    }

    public static void startServer(ServerGUI serverGUI) {
        if (running) {
            return;
        }
        gui = serverGUI;

        try {
            serverSocket = new ServerSocket(PORT);
            running = true;

            gui.setServerStatus(true);
            gui.log("Server started on port " + PORT);

            while (running) {
                Socket socket = serverSocket.accept();
                ClientHandler client = new ClientHandler(socket);
                clients.add(client);
                new Thread(client).start();
                gui.updateClientCount(clients.size());
            }

        } catch (IOException e) {
            if (running) {
                gui.log("Server error: " + e.getMessage());
            }
        } finally {
            running = false;
            for (ClientHandler client : clients) {
                client.closeConnection();
            }
            if (serverSocket != null) {
                try {
                    serverSocket.close();
                } catch (IOException e) {
                    // already closed
                }
            }
            gui.setServerStatus(false);
            gui.updateClientCount(clients.size());
        }
    }

    public static void stopServer() {
        running = false;
        if (gui != null) {
            gui.log("Stopping server...");
        }
        if (serverSocket != null) {
            try {
                serverSocket.close();
            } catch (IOException e) {
                // already stopped
            }
        }
    }

    public static void broadcast(String message) {
        for (ClientHandler client : clients) {
            client.sendMessage(message);
        }
    }

    // PHASE 2: send the new stock of one product to ALL users
    public static void broadcastStock(int productId) {
        broadcast("stock:" + productId + ":" + inventory.getStock(productId));
    }

    public static void removeClient(ClientHandler client) {
        clients.remove(client);
        if (gui != null) {
            gui.updateClientCount(clients.size());
        }
    }

    public static void log(String message) {
        System.out.println(message);
        if (gui != null) {
            gui.log(message);
        }
    }
}